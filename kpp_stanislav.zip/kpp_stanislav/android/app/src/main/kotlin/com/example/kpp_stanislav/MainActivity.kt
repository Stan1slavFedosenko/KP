package com.example.kpp_stanislav

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
